

<!DOCTYPE html>

<head>
Web Service
</head>

<body>

<form method="get" action="webServiceReply.php">
	<h3><select name="ticker" id="stock" >
		<option class="placeholder" selected disabled value="">Select Ticker</option>
		<option value="FB">Facebook</option>
		<option value="GOOG">Google</option>
		<option value="AMZN">Amazon</option>
		<option value="BAC">Bank of America</option>
		<option value="MSFT">Microsoft</option>
		<option value="MS">Morgan Stanley</option>
		<option value="AAPL">Apple</option>
		<option value="GS">Goldman Sachs</option>
		<option value="UBS">UBS</option>
		<option value="YHOO">Yahoo</option>					
	</select>

	<input name="updateButton" type="submit"/>
</form>	

	
</body>


</html>